require("@nomicfoundation/hardhat-toolbox");

const GANACHE_RPC_URL =
  process.env.GANACHE_RPC_URL ||
  "http://127.0.0.1:7545";

const SEPOLIA_RPC_URL =
  process.env.SEPOLIA_RPC_URL ||
  "";

const PRIVATE_KEY =
  process.env.DEPLOYER_PRIVATE_KEY ||
  "";

module.exports = {
  solidity: {
    version: "0.8.20",
    settings: {
      optimizer: {
        enabled: true,
        runs: 200
      }
    }
  },

  networks: {
    hardhat: {},

    ganache: {
      url: GANACHE_RPC_URL
    },

    sepolia: {
      url: SEPOLIA_RPC_URL,
      accounts: PRIVATE_KEY
        ? [PRIVATE_KEY]
        : []
    }
  }
};

// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title CredentialRegistry
 * @notice DFIM credential registry implementing the paper's register,
 *         verify and revoke lifecycle.
 *
 * Design alignment with the paper:
 * - Credentials are represented by a deterministic credential identifier
 *   and a hash of the off-chain credential payload.
 * - The registry stores issuer, holder DID, expiry and revocation state.
 * - Issuers must be explicitly authorized.
 * - Verification is a read-only operation and therefore does not mutate state.
 * - Revocation is recorded on-chain.
 *
 * Privacy:
 * - The contract does NOT store the complete credential document.
 * - The intended workflow stores large credential payloads off-chain
 *   (e.g. IPFS) and commits a hash/reference on-chain.
 */
contract CredentialRegistry {
    struct Credential {
        bytes32 credentialHash;
        address issuer;
        uint64 issuedAt;
        uint64 expiresAt;
        bool revoked;
        bool exists;
        string holderDID;
        string issuerDID;
        string revocationRegistry;
        string metadataURI;
    }

    address public owner;

    mapping(address => bool) public authorizedIssuers;
    mapping(bytes32 => Credential) private credentials;
    mapping(bytes32 => bool) public registeredCredentialIds;

    event IssuerAuthorizationChanged(
        address indexed issuer,
        bool authorized
    );

    event CredentialRegistered(
        bytes32 indexed credentialId,
        bytes32 indexed credentialHash,
        address indexed issuer,
        string holderDID,
        string issuerDID,
        uint64 expiresAt,
        string metadataURI
    );

    event CredentialRevoked(
        bytes32 indexed credentialId,
        address indexed issuer,
        uint64 revokedAt
    );

    modifier onlyOwner() {
        require(msg.sender == owner, "Registry: caller is not owner");
        _;
    }

    modifier onlyAuthorizedIssuer() {
        require(
            authorizedIssuers[msg.sender],
            "Registry: caller is not authorized issuer"
        );
        _;
    }

    constructor() {
        owner = msg.sender;
        authorizedIssuers[msg.sender] = true;
        emit IssuerAuthorizationChanged(msg.sender, true);
    }

    /**
     * @notice Authorize or de-authorize an issuer.
     */
    function setIssuerAuthorization(
        address issuer,
        bool authorized
    ) external onlyOwner {
        require(issuer != address(0), "Registry: zero issuer");

        authorizedIssuers[issuer] = authorized;

        emit IssuerAuthorizationChanged(issuer, authorized);
    }

    /**
     * @notice Register a credential commitment.
     *
     * credentialHash should be the hash of the canonicalized credential
     * representation. The full credential remains off-chain.
     */
    function registerCredential(
        bytes32 credentialId,
        bytes32 credentialHash,
        string calldata holderDID,
        string calldata issuerDID,
        uint64 expiresAt,
        string calldata revocationRegistry,
        string calldata metadataURI
    ) external onlyAuthorizedIssuer {
        require(
            credentialId != bytes32(0),
            "Registry: empty credential id"
        );

        require(
            credentialHash != bytes32(0),
            "Registry: empty credential hash"
        );

        require(
            !registeredCredentialIds[credentialId],
            "Registry: credential already registered"
        );

        if (expiresAt != 0) {
            require(
                expiresAt > block.timestamp,
                "Registry: expiry must be in future"
            );
        }

        credentials[credentialId] = Credential({
            credentialHash: credentialHash,
            issuer: msg.sender,
            issuedAt: uint64(block.timestamp),
            expiresAt: expiresAt,
            revoked: false,
            exists: true,
            holderDID: holderDID,
            issuerDID: issuerDID,
            revocationRegistry: revocationRegistry,
            metadataURI: metadataURI
        });

        registeredCredentialIds[credentialId] = true;

        emit CredentialRegistered(
            credentialId,
            credentialHash,
            msg.sender,
            holderDID,
            issuerDID,
            expiresAt,
            metadataURI
        );
    }

    /**
     * @notice Revoke a previously registered credential.
     */
    function revokeCredential(
        bytes32 credentialId
    ) external onlyAuthorizedIssuer {
        Credential storage credential = credentials[credentialId];

        require(
            credential.exists,
            "Registry: credential does not exist"
        );

        require(
            credential.issuer == msg.sender || msg.sender == owner,
            "Registry: caller is not credential issuer"
        );

        require(
            !credential.revoked,
            "Registry: credential already revoked"
        );

        credential.revoked = true;

        emit CredentialRevoked(
            credentialId,
            msg.sender,
            uint64(block.timestamp)
        );
    }

    /**
     * @notice Verify a credential commitment.
     *
     * Returns the individual state components as well as the final validity
     * decision so clients can distinguish a hash mismatch, revocation,
     * and expiration.
     */
    function verifyCredential(
        bytes32 credentialId,
        bytes32 presentedCredentialHash
    )
        public
        view
        returns (
            bool valid,
            bool revoked,
            bool expired,
            bool hashMatches,
            address issuer
        )
    {
        Credential memory credential = credentials[credentialId];

        if (!credential.exists) {
            return (
                false,
                false,
                false,
                false,
                address(0)
            );
        }

        bool isExpired =
            credential.expiresAt != 0 &&
            block.timestamp > credential.expiresAt;

        bool isHashMatch =
            credential.credentialHash == presentedCredentialHash;

        bool isValid =
            isHashMatch &&
            !credential.revoked &&
            !isExpired;

        return (
            isValid,
            credential.revoked,
            isExpired,
            isHashMatch,
            credential.issuer
        );
    }

    /**
     * @notice Return the stored credential record.
     */
    function getCredential(
        bytes32 credentialId
    ) external view returns (Credential memory) {
        require(
            credentials[credentialId].exists,
            "Registry: credential does not exist"
        );

        return credentials[credentialId];
    }

    /**
     * @notice Convenience function for clients that only need validity.
     */
    function isCredentialValid(
        bytes32 credentialId,
        bytes32 presentedCredentialHash
    ) external view returns (bool) {
        (bool valid,,,,) = verifyCredential(
            credentialId,
            presentedCredentialHash
        );

        return valid;
    }

    /**
     * @notice Ownership transfer for administrative control.
     */
    function transferOwnership(
        address newOwner
    ) external onlyOwner {
        require(
            newOwner != address(0),
            "Registry: zero owner"
        );

        owner = newOwner;
    }
}

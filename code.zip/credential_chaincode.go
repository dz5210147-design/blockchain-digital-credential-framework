package main

import (
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-contract-api-go/contractapi"
)

/*
DFIM Credential Chaincode

This chaincode mirrors the smart-contract lifecycle used in the EVM
implementation:

    register credential
    verify credential
    revoke credential

The ledger stores a commitment-oriented credential record rather than the
complete credential document. This supports the manuscript's separation of
on-chain integrity/revocation state from off-chain credential storage.
*/

type SmartContract struct {
	contractapi.Contract
}

type Credential struct {
	CredentialID       string `json:"credential_id"`
	CredentialHash     string `json:"credential_hash"`
	HolderDID          string `json:"holder_did"`
	IssuerDID          string `json:"issuer_did"`
	IssueDate          string `json:"issue_date"`
	ExpiryDate         string `json:"expiry_date"`
	Status             string `json:"status"`
	RevocationRegistry string `json:"revocation_registry"`
	MetadataURI        string `json:"metadata_uri"`
}

/*
RegisterCredential creates a new credential record.
*/
func (s *SmartContract) RegisterCredential(
	ctx contractapi.TransactionContextInterface,
	credentialID string,
	credentialHash string,
	holderDID string,
	issuerDID string,
	issueDate string,
	expiryDate string,
	revocationRegistry string,
	metadataURI string,
) error {

	if credentialID == "" {
		return fmt.Errorf("credential ID cannot be empty")
	}

	if credentialHash == "" {
		return fmt.Errorf("credential hash cannot be empty")
	}

	existing, err := ctx.GetStub().GetState(credentialID)
	if err != nil {
		return fmt.Errorf("failed to read credential: %w", err)
	}

	if existing != nil {
		return fmt.Errorf(
			"credential %s already exists",
			credentialID,
		)
	}

	credential := Credential{
		CredentialID:       credentialID,
		CredentialHash:     credentialHash,
		HolderDID:          holderDID,
		IssuerDID:          issuerDID,
		IssueDate:          issueDate,
		ExpiryDate:         expiryDate,
		Status:             "active",
		RevocationRegistry: revocationRegistry,
		MetadataURI:        metadataURI,
	}

	payload, err := json.Marshal(credential)
	if err != nil {
		return fmt.Errorf("failed to serialize credential: %w", err)
	}

	if err := ctx.GetStub().PutState(
		credentialID,
		payload,
	); err != nil {
		return fmt.Errorf("failed to write credential: %w", err)
	}

	return nil
}

/*
RevokeCredential changes the ledger state to revoked.
*/
func (s *SmartContract) RevokeCredential(
	ctx contractapi.TransactionContextInterface,
	credentialID string,
) error {

	credential, err := s.getCredential(
		ctx,
		credentialID,
	)
	if err != nil {
		return err
	}

	if credential.Status == "revoked" {
		return fmt.Errorf(
			"credential %s is already revoked",
			credentialID,
		)
	}

	credential.Status = "revoked"

	return s.putCredential(
		ctx,
		credential,
	)
}

/*
VerifyCredential checks the presented credential hash and ledger status.
*/
func (s *SmartContract) VerifyCredential(
	ctx contractapi.TransactionContextInterface,
	credentialID string,
	presentedHash string,
) (bool, error) {

	credential, err := s.getCredential(
		ctx,
		credentialID,
	)
	if err != nil {
		return false, err
	}

	if credential.Status != "active" {
		return false, nil
	}

	return credential.CredentialHash == presentedHash, nil
}

/*
GetCredential returns a complete stored credential record.
*/
func (s *SmartContract) GetCredential(
	ctx contractapi.TransactionContextInterface,
	credentialID string,
) (*Credential, error) {

	return s.getCredential(
		ctx,
		credentialID,
	)
}

/*
CredentialExists provides a cheap existence query.
*/
func (s *SmartContract) CredentialExists(
	ctx contractapi.TransactionContextInterface,
	credentialID string,
) (bool, error) {

	value, err := ctx.GetStub().GetState(
		credentialID,
	)

	if err != nil {
		return false, err
	}

	return value != nil, nil
}

/*
GetCredentialsByIssuer retrieves credentials associated with an issuer DID.

This uses a CouchDB-compatible JSON selector when the Fabric deployment
uses CouchDB as the state database.
*/
func (s *SmartContract) GetCredentialsByIssuer(
	ctx contractapi.TransactionContextInterface,
	issuerDID string,
) ([]*Credential, error) {

	query := fmt.Sprintf(
		`{"selector":{"issuer_did":"%s"}}`,
		issuerDID,
	)

	resultsIterator, err := ctx.GetStub().GetQueryResult(
		query,
	)

	if err != nil {
		return nil, err
	}

	defer resultsIterator.Close()

	var results []*Credential

	for resultsIterator.HasNext() {
		queryResult, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}

		var credential Credential

		if err := json.Unmarshal(
			queryResult.Value,
			&credential,
		); err != nil {
			return nil, err
		}

		results = append(results, &credential)
	}

	return results, nil
}

func (s *SmartContract) getCredential(
	ctx contractapi.TransactionContextInterface,
	credentialID string,
) (*Credential, error) {

	value, err := ctx.GetStub().GetState(
		credentialID,
	)

	if err != nil {
		return nil, fmt.Errorf(
			"failed to read credential %s: %w",
			credentialID,
			err,
		)
	}

	if value == nil {
		return nil, fmt.Errorf(
			"credential %s does not exist",
			credentialID,
		)
	}

	var credential Credential

	if err := json.Unmarshal(
		value,
		&credential,
	); err != nil {
		return nil, fmt.Errorf(
			"failed to decode credential %s: %w",
			credentialID,
			err,
		)
	}

	return &credential, nil
}

func (s *SmartContract) putCredential(
	ctx contractapi.TransactionContextInterface,
	credential *Credential,
) error {

	payload, err := json.Marshal(
		credential,
	)

	if err != nil {
		return fmt.Errorf(
			"failed to encode credential: %w",
			err,
		)
	}

	return ctx.GetStub().PutState(
		credential.CredentialID,
		payload,
	)
}

func main() {
	chaincode, err := contractapi.NewChaincode(
		&SmartContract{},
	)

	if err != nil {
		panic(
			fmt.Sprintf(
				"failed to create chaincode: %v",
				err,
			),
		)
	}

	if err := chaincode.Start(); err != nil {
		panic(
			fmt.Sprintf(
				"failed to start chaincode: %v",
				err,
			),
		)
	}
}

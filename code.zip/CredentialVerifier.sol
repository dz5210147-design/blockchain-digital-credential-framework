// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title ICredentialRegistry
 * @notice Interface consumed by the ZKP verification facade.
 */
interface ICredentialRegistry {
    function verifyCredential(
        bytes32 credentialId,
        bytes32 presentedCredentialHash
    )
        external
        view
        returns (
            bool valid,
            bool revoked,
            bool expired,
            bool hashMatches,
            address issuer
        );
}

/**
 * @title IGroth16Verifier
 * @notice Standard verifier interface compatible with a generated
 *         Groth16 verifier contract.
 *
 * A generated verifier can be supplied by snarkjs/circom tooling without
 * changing the credential registry.
 */
interface IGroth16Verifier {
    function verifyProof(
        uint256[2] calldata a,
        uint256[2][2] calldata b,
        uint256[2] calldata c,
        uint256[] calldata publicSignals
    ) external view returns (bool);
}

/**
 * @title CredentialVerifier
 * @notice On-chain verification facade combining:
 *         (1) registry state checks, and
 *         (2) a Groth16 ZKP verifier.
 *
 * The manuscript reports a ZKP verification cost of 84,920 gas for its
 * evaluated verification path. This implementation provides the executable
 * contract interface for that workflow; measured gas remains dependent on
 * the concrete generated verifier and compiler/runtime configuration.
 */
contract CredentialVerifier {
    ICredentialRegistry public immutable registry;
    IGroth16Verifier public immutable zkVerifier;

    event ZKCredentialVerified(
        bytes32 indexed credentialId,
        bool proofValid,
        bool registryValid
    );

    constructor(
        address registryAddress,
        address zkVerifierAddress
    ) {
        require(
            registryAddress != address(0),
            "Verifier: zero registry"
        );

        require(
            zkVerifierAddress != address(0),
            "Verifier: zero ZKP verifier"
        );

        registry = ICredentialRegistry(registryAddress);
        zkVerifier = IGroth16Verifier(zkVerifierAddress);
    }

    /**
     * @notice Verify registry state only.
     */
    function verifyRegistryState(
        bytes32 credentialId,
        bytes32 credentialHash
    )
        public
        view
        returns (
            bool valid,
            bool revoked,
            bool expired,
            bool hashMatches,
            address issuer
        )
    {
        return registry.verifyCredential(
            credentialId,
            credentialHash
        );
    }

    /**
     * @notice Verify a Groth16 proof and require the credential registry
     *         state to remain valid.
     *
     * publicSignals[0] is expected to identify/bind the credential commitment
     * in the circuit-specific implementation. Because circuit public-signal
     * ordering can vary, this generic facade leaves exact signal encoding to
     * the generated verifier/client.
     */
    function verifyCredentialProof(
        bytes32 credentialId,
        bytes32 credentialHash,
        uint256[2] calldata a,
        uint256[2][2] calldata b,
        uint256[2] calldata c,
        uint256[] calldata publicSignals
    ) external returns (bool) {
        (
            bool registryValid,
            ,
            ,
            ,
        ) = registry.verifyCredential(
            credentialId,
            credentialHash
        );

        require(
            registryValid,
            "Verifier: registry credential invalid"
        );

        bool proofValid = zkVerifier.verifyProof(
            a,
            b,
            c,
            publicSignals
        );

        emit ZKCredentialVerified(
            credentialId,
            proofValid,
            registryValid
        );

        return proofValid;
    }
}

const { ethers } = require("hardhat");

/*
 * DFIM deployment script
 *
 * Deployment order:
 *   1. CredentialRegistry
 *   2. authorize issuer
 *   3. deploy an externally generated Groth16 verifier
 *   4. CredentialVerifier(registry, zkVerifier)
 *
 * The ZKP verifier address can be supplied through ZK_VERIFIER_ADDRESS.
 *
 * Example:
 *   npx hardhat run deploy.js --network ganache
 *
 * For a first deployment without a generated ZKP verifier, the script can
 * deploy only the registry by setting DEPLOY_REGISTRY_ONLY=true.
 */

async function main() {
  const [deployer, issuer] =
    await ethers.getSigners();

  console.log("DFIM deployment");
  console.log(
    "Deployer:",
    deployer.address
  );
  console.log(
    "Issuer:",
    issuer.address
  );

  const Registry =
    await ethers.getContractFactory(
      "CredentialRegistry"
    );

  const registry =
    await Registry.deploy();

  await registry.waitForDeployment();

  const registryAddress =
    await registry.getAddress();

  console.log(
    "CredentialRegistry:",
    registryAddress
  );

  await (
    await registry.setIssuerAuthorization(
      issuer.address,
      true
    )
  ).wait();

  console.log(
    "Issuer authorized:",
    issuer.address
  );

  if (
    process.env.DEPLOY_REGISTRY_ONLY === "true"
  ) {
    console.log(
      "DEPLOY_REGISTRY_ONLY=true; stopping after registry deployment."
    );
    return;
  }

  const zkVerifierAddress =
    process.env.ZK_VERIFIER_ADDRESS;

  if (!zkVerifierAddress) {
    throw new Error(
      "ZK_VERIFIER_ADDRESS is required for CredentialVerifier deployment. " +
      "Deploy/export a concrete Groth16 verifier first."
    );
  }

  const Verifier =
    await ethers.getContractFactory(
      "CredentialVerifier"
    );

  const verifier =
    await Verifier.deploy(
      registryAddress,
      zkVerifierAddress
    );

  await verifier.waitForDeployment();

  const verifierAddress =
    await verifier.getAddress();

  console.log(
    "CredentialVerifier:",
    verifierAddress
  );

  const deployment =
    {
      network:
        hre.network.name,
      deployer:
        deployer.address,
      issuer:
        issuer.address,
      CredentialRegistry:
        registryAddress,
      CredentialVerifier:
        verifierAddress,
      ZKVerifier:
        zkVerifierAddress,
      compiler:
        "solidity-0.8.20"
    };

  const fs =
    require("fs");

  fs.writeFileSync(
    "deployment.json",
    JSON.stringify(
      deployment,
      null,
      2
    )
  );

  console.log(
    "Wrote deployment.json"
  );
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });

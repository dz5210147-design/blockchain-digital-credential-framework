pragma circom 2.1.6;

/*
 * DFIM credential-policy ZKP circuit
 *
 * Public inputs:
 *   threshold
 *   revoked
 *
 * Private input:
 *   age
 *
 * Statement proved:
 *   1. age >= threshold
 *   2. revoked == 0
 *
 * This is deliberately aligned with the manuscript's reported test vectors:
 *   TV-1: valid signature, threshold met, not revoked -> verified
 *   TV-2: valid signature, threshold not met, not revoked -> rejected
 *   TV-3: valid signature, threshold met, revoked -> rejected
 *
 * The manuscript reports an evaluated circuit of approximately 18,500
 * constraints. This compact implementation expresses the same policy
 * semantics but is not claimed to reproduce that exact unpublished circuit
 * size.
 */

include "circomlib/circuits/comparators.circom";

template CredentialPolicy() {
    signal input age;
    signal input threshold;
    signal input revoked;

    signal output valid;

    component ageCheck = GreaterEqThan(16);

    ageCheck.in[0] <== age;
    ageCheck.in[1] <== threshold;

    // Revocation is a binary policy input.
    revoked * (revoked - 1) === 0;

    // A credential is valid iff it meets the threshold and is not revoked.
    valid <== ageCheck.out * (1 - revoked);

    // Explicitly constrain the output to Boolean.
    valid * (valid - 1) === 0;
}

component main {public [threshold, revoked]} = CredentialPolicy();

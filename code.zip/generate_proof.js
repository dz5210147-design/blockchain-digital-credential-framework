#!/usr/bin/env node

/**
 * DFIM ZKP proof-generation utility.
 *
 * Workflow:
 *   node generate_proof.js --case TV-1
 *
 * Prerequisites:
 *   npm install
 *
 * Expected build artifacts:
 *   build/credential_js/credential.wasm
 *   proving_key.zkey
 *
 * The script:
 *   1. loads the selected test vector,
 *   2. builds a witness input,
 *   3. invokes snarkjs Groth16 proof generation,
 *   4. writes proof.json, public.json and witness.wtns.
 *
 * The script intentionally keeps private inputs (e.g. age) out of
 * public.json.
 */

const fs = require("fs");
const path = require("path");
const snarkjs = require("snarkjs");

const ROOT = __dirname;
const BUILD_DIR = path.join(ROOT, "build");
const WASM = path.join(
  BUILD_DIR,
  "credential_js",
  "credential.wasm"
);
const ZKEY = path.join(ROOT, "proving_key.zkey");
const VECTOR_FILE = path.join(ROOT, "zkp_test_vectors.json");
const OUTPUT_DIR = path.join(ROOT, "proofs");

const vectors = JSON.parse(
  fs.readFileSync(VECTOR_FILE, "utf8")
);

function argument(name, fallback = undefined) {
  const index = process.argv.indexOf(name);
  if (index === -1) return fallback;
  return process.argv[index + 1];
}

function selectVector(id) {
  const vector = vectors.find((item) => item.id === id);

  if (!vector) {
    throw new Error(
      `Unknown test vector '${id}'. Available: ${vectors
        .map((x) => x.id)
        .join(", ")}`
    );
  }

  return vector;
}

function buildInput(vector) {
  /*
   * The manuscript test vectors expose threshold/revocation outcomes but
   * do not specify the exact private age values. We use deterministic
   * representative values solely for executing this reconstructed circuit.
   *
   * TV-1: 25 >= 18
   * TV-2: 17 < 18
   * TV-3: 25 >= 18 but revoked
   */
  const privateAge = {
    "TV-1": 25,
    "TV-2": 17,
    "TV-3": 25
  }[vector.id];

  if (privateAge === undefined) {
    throw new Error(`No reconstructed private input for ${vector.id}`);
  }

  return {
    age: privateAge,
    threshold: 18,
    revoked: vector.revoked ? 1 : 0
  };
}

async function main() {
  const caseId = argument("--case", "TV-1");
  const vector = selectVector(caseId);

  if (!fs.existsSync(WASM)) {
    throw new Error(
      `Missing WASM artifact: ${WASM}\n` +
      `Compile credential.circom first with circom 2.x.`
    );
  }

  if (!fs.existsSync(ZKEY)) {
    throw new Error(
      `Missing proving key: ${ZKEY}\n` +
      `Run the trusted setup before proof generation.`
    );
  }

  fs.mkdirSync(OUTPUT_DIR, { recursive: true });

  const input = buildInput(vector);
  const inputPath = path.join(
    OUTPUT_DIR,
    `${caseId}.input.json`
  );

  const witnessPath = path.join(
    OUTPUT_DIR,
    `${caseId}.wtns`
  );

  const proofPath = path.join(
    OUTPUT_DIR,
    `${caseId}.proof.json`
  );

  const publicPath = path.join(
    OUTPUT_DIR,
    `${caseId}.public.json`
  );

  fs.writeFileSync(
    inputPath,
    JSON.stringify(input, null, 2)
  );

  console.log(`[DFIM] Generating witness for ${caseId}...`);

  await snarkjs.wtns.calculate(
    input,
    WASM,
    witnessPath
  );

  console.log(`[DFIM] Generating Groth16 proof for ${caseId}...`);

  const { proof, publicSignals } =
    await snarkjs.groth16.prove(
      ZKEY,
      witnessPath
    );

  fs.writeFileSync(
    proofPath,
    JSON.stringify(proof, null, 2)
  );

  fs.writeFileSync(
    publicPath,
    JSON.stringify(publicSignals, null, 2)
  );

  console.log(
    JSON.stringify(
      {
        vector: caseId,
        proof: proofPath,
        publicSignals: publicPath,
        witness: witnessPath,
        expected: vector.expected
      },
      null,
      2
    )
  );
}

main().catch((error) => {
  console.error("[DFIM] Proof generation failed:");
  console.error(error);
  process.exit(1);
});
